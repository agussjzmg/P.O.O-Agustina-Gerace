﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 5. Escribir un programa que pida ingresar la coordenada de un punto en el plano.
             Luego imprimir en pantalla en que cuadrante se ubica dicho punto.*/

            int x, y;
            string linea;

            Console.Write("Ingrese la coordenada X: ");
            linea = Console.ReadLine();
            x = int.Parse(linea);

            Console.Write("Ingrese la coordenada Y: ");
            linea = Console.ReadLine();
            y = int.Parse(linea);

            if (x > 0 && y > 0)
            {
                Console.WriteLine("Primer Cuadrante");
            }
            else if (x < 0 && y > 0)
            {
                Console.WriteLine("Segundo Cuadrante");
            }
            else if (x < 0 && y < 0)
            {
                Console.WriteLine("Tercer Cuadrante");
            }
            else if (x > 0 && y < 0)
            {
                Console.WriteLine("Cuarto Cuadrante");
            }

            Console.ReadKey();
        }
    }
}
