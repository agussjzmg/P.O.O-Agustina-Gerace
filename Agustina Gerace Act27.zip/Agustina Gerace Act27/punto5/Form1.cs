﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace punto5
{
    /*Actividad 5: Configuración de Suscripción
    Problema:
    Una aplicación ofrece distintos niveles de suscripción.
    Requisitos:
    ● Usar un ComboBox para elegir el tipo de plan: &quot;Gratis&quot;, &quot;Básico&quot;, &quot;Premium&quot;.
    ● Incluir dos CheckBox para elegir servicios adicionales (por ejemplo: &quot;Soporte
    técnico&quot;, &quot;Acceso anticipado&quot;).
    ● Al presionar el botón &quot;Guardar&quot;, se debe mostrar en un Label un resumen con el
    plan y los servicios elegidos.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Text = "Plan: " + comboBox1.Text + "-";
            if (comboBox1.Text == "Gratis") 
            {
                label3.Text += " El acceso es limitado a contenido ";
            }

            if (comboBox1.Text == "Básico")
            {
                label3.Text += "Acceso a contenido completo ";
            }

            if (comboBox1.Text == "Premium")
            {
                label3.Text += "Acceso completo y beneficios exclusivos ";
            }

            if (checkBox1.Checked == true)
            {
                label3.Text += " y cuenta con \r\n soporte técnico, lo que significa que podes" +
                    " hablar con un experto \r\n o enviar mensajes privados para solucionar" +
                    "errores y una explicación \r\n paso a paso ";
            }

            if (checkBox2.Checked == true)
            {
                label3.Text += " y cuenta \r\n con acceso anticipado que significa que " +
                    "podras ver \r\n el contenido antes de que se vuelva visible para todo el mundo ";
            }
        }
    }
    
}
