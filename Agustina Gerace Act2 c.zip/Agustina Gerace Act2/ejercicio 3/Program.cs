﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 3. Se ingresa por teclado un número positivo de uno o dos dígitos
             * (1..99) mostrar un mensaje indicando si el número tiene uno o dos dígitos.
             * (Tener en cuenta que condición debe cumplirse para tener dos dígitos, un número entero)*/
            int num;
            string linea;
            Console.Write("ingrese un numero: ");
            linea = Console.ReadLine();
            num = int.Parse(linea);
            if (num > 9)
            {
                Console.Write("su numero tiene dos cifras");
            }
            else {
                Console.Write("su numero tiene una cifra");
            }
            
            Console.ReadKey();
        }
    }
}

