﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 2. Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado" */
            float nota1;
            float nota2;
            float nota3; 
            float nota4;
            float nota5;
            float nota6;
            string linea;
            float promedio;

            Console.Write("ingrese nota 1: ");
            linea = Console.ReadLine();
            nota1 = float.Parse(linea);

            Console.Write("ingrese nota 2: ");
            linea = Console.ReadLine();
            nota2 = float.Parse(linea);

            Console.Write("ingrese nota 3: ");
            linea = Console.ReadLine();
            nota3 = float.Parse(linea);

            Console.Write("ingrese nota 4: ");
            linea = Console.ReadLine();
            nota4 = float.Parse(linea);

            Console.Write("ingrese nota 5: ");
            linea = Console.ReadLine();
            nota5 = float.Parse(linea);

            Console.Write("ingrese nota 6: ");
            linea = Console.ReadLine();
            nota6 = float.Parse(linea);

            promedio = (nota1 + nota2 + nota3 + nota4 + nota5 + nota6) / 6;

         if (promedio >= 7){
                Console.Write("PROMOCIONADO, su promedio es de: ");
                Console.WriteLine(promedio);
            }
            Console.ReadKey();
        }
    }
}
