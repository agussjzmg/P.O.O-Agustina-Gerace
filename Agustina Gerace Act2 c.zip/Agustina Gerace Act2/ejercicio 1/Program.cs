﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 1. Realizar un programa que lea por teclado dos números, 
             * si el primero es mayor al segundo informar su suma y diferencia,
             * en caso contrario informar el producto y la división del primero respecto al segundo */
            int num1;
            int num2;
            string linea;
            int suma;
            int producto;
            int div;
            int resta;

            Console.Write("ingrese el primer numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese el segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);
            
            suma = num1 + num2;
            resta = num1 - num2;
            producto = num1 * num2;
            div = num2 / num1;
            if (num1 > num2)
            {
                Console.Write("La suma de ambos numeros es: ");
                Console.WriteLine(suma);
                Console.Write("La diferencia entre ambos es: ");
                Console.WriteLine(resta);

            }
            else {
                Console.Write("El producto es: ");
                Console.WriteLine(producto);
                Console.Write("El resultado de la division es: ");
                Console.WriteLine(div);
            }
            Console.ReadKey();
        }
    }
}
