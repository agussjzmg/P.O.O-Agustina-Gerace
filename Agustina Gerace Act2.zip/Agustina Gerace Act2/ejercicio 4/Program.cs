﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1;
            int num2;
            int num3;
            string linea;

            Console.Write("ingrese el primer numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese el segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("ingrese el tercer numero: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            if (num1 > num2 && num1 > num3){
                Console.Write("el mayor es el numero 1: ");
                Console.WriteLine(num1);
            }
            else
            {
                if (num2> num1 && num2 > num3)
                {
                    Console.Write("el mayor es el numero 2: ");
                    Console.WriteLine(num2);
                }
            
        
             else 
            {
                Console.Write("el mayor es el numero 3: ");
                Console.WriteLine(num3);


            }
            }
        }

    }

}


