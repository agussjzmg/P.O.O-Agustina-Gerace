﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            string linea;
            Console.Write("ingrese un numero: ");
            linea = Console.ReadLine();
            num = int.Parse(linea);
            if (num > 9)
            {
                Console.Write("su numero tiene dos cifras");
            }
            else {
                Console.Write("su numero tiene una cifra");
            }
            
            Console.ReadKey();
        }
    }
}

