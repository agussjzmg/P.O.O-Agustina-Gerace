﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto5
{
    /*5. Visor Dinámico de Imágenes (Investigación: PictureBox)
    ● Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y
    SizeMode.
    ● Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
    el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
    PictureBox.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmCqklijEJXvcCctrYCHtExLtWRQ5Z6wxvsYDMv73fIw&s=10";
            }
            if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6rlTFZzbj6BPRu5dF3v8cxSc3XtjcD5jQqSF4hUZWEw&s=10";
            }
            if (comboBox1.SelectedIndex == 2)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8zufe6LZbPISRRuD8k31Y80J9xgyHQxWV4uH84IV7qybIyX3BYvBUfQ5Z&s=10";
            }
            if (comboBox1.SelectedIndex == 3)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT4rAIbCtsYgfzs1htUsxo6tgcWMNI6jb1uf9GJsyHXfA&s=10";
            }
            if (comboBox1.SelectedIndex == 4)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRKn-RmmWBM5vUBjmLoAFQv_ciarzEwWCYgqhx2p7IbXG5-JwsjQaaKA9c&s=10";
            }
            if (comboBox1.SelectedIndex == 5)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQx9K2zOTlUTrGWOb-q84cJUei4YmZDgwfJ68f0hZDtZg&s=10";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
