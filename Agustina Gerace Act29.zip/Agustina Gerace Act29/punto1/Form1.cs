﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto1
{
    /*6. Simulador de Carrito de Compras
    ● Consigna: Disponer tres CheckBox con productos y precios fijos. Un Button
    &quot;Calcular Total&quot; debe evaluar los controles seleccionados (Checked == true), sumar
    sus costos y mostrar el monto final en un Label.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1 = 3500;
            int num2 = 5000;
            int num3 = 7000;
            int suma = 0;
            if (checkBox1.Checked == true)
            {
                suma = suma + num1;
            }
            if (checkBox2.Checked == true)
            {
                suma = suma + num2;
            }
            if (checkBox3.Checked == true)
            {
                suma = suma + num3;
            }

            label2.Text = "$" + suma.ToString();
        }
    }
}
