﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*5. Realizar la carga del radio de un círculo, mostrar por pantalla 
             * la circunferencia y el área del mismo (La circunferencia se
             * calcula multiplicando el doble del radio por π (pi), y el área
             * se calcula multiplicando π por el cuadrado del radio). */
            int radio;
            string linea;
            double circunferencia;
            double area;

            Console.Write("ingrese el radio de la circunferencia: ");
            linea = Console.ReadLine();
            radio = int.Parse(linea);

            float pi = 3.14f;
            circunferencia = 2 * radio * pi;
            area = pi * radio * radio;

            Console.WriteLine("La circunferencia es: " + circunferencia);
            Console.WriteLine("El area: " + area);

            Console.ReadKey();
        }
    }
}
