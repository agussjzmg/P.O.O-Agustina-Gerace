﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*2. Escribir un programa en el cual se ingresen cuatro números, 
            calcular e informar la suma de los dos primeros y el producto del tercero y el cuarto. */
            int num1;
            int num2;
            int num3;
            int num4;
            string linea;
            int suma;
            int producto;

            Console.Write("ingrese el primer numero a sumar: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese el segundo numero a sumar: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("ingrese el tercer numero a multiplicar: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            Console.Write("ingrese el cuarto numero a multiplicar: ");
            linea = Console.ReadLine();
            num4 = int.Parse(linea);

            suma = num1 + num2;
            producto = num3 * num4;

            Console.Write("La suma de ambos primeros numeros es: ");
            Console.WriteLine(suma);

            Console.Write("El producto de los dos ultimos numeros es: ");
            Console.WriteLine(producto);

            Console.ReadKey();
        }
    }
}
