﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 1. Realizar la carga del lado de un cuadrado, 
             * mostrar por pantalla el perímetro del mismo (El perímetro de un 
             * cuadrado se calcula multiplicando el valor del lado por cuatro) */
            int num1;
            string linea;
            int perimetro;

            Console.Write("ingrese el lado de un cuadrado: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            perimetro = num1 * 4;

            Console.Write("El perimetro es: ");
            Console.WriteLine(perimetro);

            Console.ReadKey();
        }
    }
}
