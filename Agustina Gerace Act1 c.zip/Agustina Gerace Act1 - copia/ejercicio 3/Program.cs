﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 3. Realizar un programa que lea cuatro valores numéricos e informar su suma y promedio. */
            int num1;
            int num2;
            int num3;
            int num4;
            string linea;
            int suma;
            int promedio;

            Console.Write("ingrese el primer numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese el segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("ingrese el tercer numero: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            Console.Write("ingrese el cuarto numero: ");
            linea = Console.ReadLine();
            num4 = int.Parse(linea);

            suma = num1 + num2 + num3 + num4;
            promedio = suma / 4;

            Console.Write("La suma de los numeros es: ");
            Console.WriteLine(suma);

            Console.Write("El promedio de los numeros es: ");
            Console.WriteLine(promedio);

            Console.ReadKey();
        }
    }
}
