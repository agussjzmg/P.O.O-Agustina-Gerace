﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1.Realizar un programa que pida cargar una fecha cualquiera, luego verificar si dicha fecha corresponde a Navidad.
            int dia, mes;
            string linea;

            Console.Write("Ingrese el dia: ");
            linea = Console.ReadLine();
            dia = int.Parse(linea);

            Console.Write("Ingrese el mes: ");
            linea = Console.ReadLine();
            mes = int.Parse(linea);

            if (dia == 25 && mes == 12)
            {
                Console.WriteLine("La fecha ingresada corresponde a Navidad");
            }
            else
            {
                Console.WriteLine("La fecha ingresada no corresponde a Navidad");
            }

            Console.ReadKey();
        
        }
    }
}
